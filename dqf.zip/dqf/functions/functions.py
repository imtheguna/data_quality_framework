# Databricks notebook source
def mount_adls(storage_account_name, container_name):
    # Get secrets from Key Vault
    client_id = "8d83dd0e-4359-4528-a9df-e5455fdf4224"
    tenant_id = "276bf9b8-b404-4825-969c-7ae22eeee0d4"
    client_secret = "xMQ8Q~iIh~UC-Wonxt0-fmapxvHoa4Bszwwl~c5Z"
    
    # Set spark configurations
    configs = {"fs.azure.account.auth.type": "OAuth",
              "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
              "fs.azure.account.oauth2.client.id": client_id,
              "fs.azure.account.oauth2.client.secret": client_secret,
              "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}
    
    # Unmount the mount point if it already exists
    if any(mount.mountPoint == f"/mnt/{storage_account_name}/{container_name}" for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(f"/mnt/{storage_account_name}/{container_name}")
    
    # Mount the storage account container
    dbutils.fs.mount(
      source = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/",
      mount_point = f"/mnt/{storage_account_name}/{container_name}",
      extra_configs = configs)
    
    display(dbutils.fs.mounts())

# COMMAND ----------

mount_adls('dqf', 'raw')

# COMMAND ----------

mount_adls('dqf', 'error')

# COMMAND ----------

mount_adls('dqf', 'dqf-source')

# COMMAND ----------

mount_adls('dqf', 'setup-files')

# COMMAND ----------

mount_adls('dqf', 'presentation')

# COMMAND ----------

mount_adls('dqf', 'processed')