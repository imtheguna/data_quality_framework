# Databricks notebook source
# MAGIC %run "../../dq-rules-setup/configuration"

# COMMAND ----------

# MAGIC %run "../../dq-rules-setup/1.db_functions"

# COMMAND ----------

path = f'{rules_folder_path}/rules.csv'

# COMMAND ----------

if not os.path.exists('/'+path.replace(':','')):
    dbutils.notebook.exit("The file does not exist")

# COMMAND ----------

df = spark.read.option('header',True).option('inferschema','true').csv(path)

# COMMAND ----------

final_df = add_ingestion_date(df,'rec_ins_ts')

# COMMAND ----------

insert_by_df('dq_rules',final_df)