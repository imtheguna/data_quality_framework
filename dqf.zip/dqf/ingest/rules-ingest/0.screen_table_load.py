# Databricks notebook source
# MAGIC %run "../../dq-rules-setup/configuration"

# COMMAND ----------

# MAGIC %run "../../dq-rules-setup/1.db_functions"

# COMMAND ----------

df = spark.read.option('header',True).option('inferschema','true').csv(f'{rules_folder_path}/scr.csv')

# COMMAND ----------

final_df = add_ingestion_date(df,'rec_ins_ts')

# COMMAND ----------

insert_by_df('screen',final_df)