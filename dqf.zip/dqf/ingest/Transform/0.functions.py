# Databricks notebook source
import logging

# COMMAND ----------

def readAllFIles(path):
    files = []
    for i in dbutils.fs.ls(path):
        files.append(i)
    return files

# COMMAND ----------

def deleteAllTheFIles(path):
   for i in dbutils.fs.ls(path):
        dbutils.fs.rm(i[0],True)

# COMMAND ----------

def logger(type,logfile):
    
    logging.basicConfig(filename=logfile, level=type, format='%(asctime)s - %(levelname)s - %(message)s')
    print(logfile)
    # with open(logfile,"a") as log:
    #     log.write(f'[{type.value}] '+msg)
    #     print(f'[{type.value}] '+msg)