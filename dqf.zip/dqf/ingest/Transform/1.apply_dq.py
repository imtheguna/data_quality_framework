# Databricks notebook source
# MAGIC %run "../../dq-rules-setup/configuration"

# COMMAND ----------

# MAGIC %run "../../dq-rules-setup/1.db_functions"

# COMMAND ----------

# MAGIC %run "./0.functions"

# COMMAND ----------

## reading all the files from path
files = readAllFIles(raw_folder_path)

## Checking Screen
scr_df = select_table('screen')

# COMMAND ----------

## Update log tables
def create_log(query):
    execute_query(query)

# COMMAND ----------

## Update screen log table
def update_scr_log(id,start_time,end_time,status,error_msg):
    error_log_query = f"""insert into dq_scr_run_log (screen_id,start_time,end_time,status,error_msg,rec_ins_ts)
                                    VALUES ({id}, '{start_time}', '{end_time}','{status}',{error_msg},current_timestamp);"""
    print(error_log_query)
    create_log(error_log_query)

# COMMAND ----------

def apply_profile_rules(source_file_df,profile_rules_df,TEMPORARY_TARGET,screen_id):
    try:
        count = 0
        ## start time
        start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        ## Reading all error records
        for row in profile_rules_df.rdd.collect():
            temp_df = spark.sql(row['rule_query'])

            if(temp_df.count()):

                ## Updating the log table
                error_log_query = f"""insert into dq_profile_alert_log (rule_id,screen_id,rule_ds,error_record_count,rec_ins_ts)
                                    VALUES ({row['rule_id']}, {row['screen_id']}, '{row['rule_ds']}',{temp_df.count()},current_timestamp);"""

                count = count+temp_df.count()

                create_log(error_log_query)

        ## end time
        end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        ## update log table with screen status
        update_scr_log(screen_id,start_time,end_time,'SUCCESS','null',)

        return count
    except Exception as e:
        end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print('Failed')
        update_scr_log(screen_id,start_time,end_time,'Failed',str(e))


# COMMAND ----------

def convert_csv_from_part(TEMPORARY_TARGET,DESIRED_TARGET):
    ## Creating the error records into error path
    TEMPORARY_TARGET1='/'+TEMPORARY_TARGET.replace(':','')
    part_filename = next(entry for entry in os.listdir(TEMPORARY_TARGET1) if entry.startswith('part-'))
    temporary_csv = os.path.join(TEMPORARY_TARGET, part_filename)
    dbutils.fs.cp(temporary_csv, DESIRED_TARGET)

# COMMAND ----------

def apply_row_rules(source_file_df,row_rules_df,TEMPORARY_TARGET,screen_id):
    try:
        count = 0
        ## start time
        start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        ## Create an empty RDD with empty schema
        filter_df = spark.createDataFrame([],
                                schema = source_file_df.schema)
        
        ## Reading all error records
        for row in row_rules_df.rdd.collect():
            temp_df = spark.sql(row['rule_query'])

            if(temp_df.count()):

                ## Updating the log table
                error_log_query = f"""insert into dq_row_alert_log (rule_id,screen_id,rule_ds,error_record_count,rec_ins_ts)
                                    VALUES ({row['rule_id']}, {row['screen_id']}, '{row['rule_ds']}',{temp_df.count()},current_timestamp);"""

                count = count+temp_df.count()

                create_log(error_log_query)

                ## Append error records
                filter_df = filter_df.union(temp_df)
        
        ## Creating error file in temp path
        filter_df.drop_duplicates()
        filter_df.repartition(1).write.mode("overwrite").option("header", "true").option("delimiter", ",").csv(TEMPORARY_TARGET)
        
        ## End time
        end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        ## update log table with screen status
        update_scr_log(screen_id,start_time,end_time,'SUCCESS','null',)

        return count
    except Exception as e:
        end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print('Failed')
        update_scr_log(screen_id,start_time,end_time,'Failed',str(e))


# COMMAND ----------

def apply_dq_rules(scr_id_dq,file): 

    ##logger(LOGTYPE.INFO,'Row rules started',log_file)
    ## Reading the Source file from raw layer
    source_file_df = spark.read.option('header','true') \
        .option('inferschema',True).csv(file[0])

    ## Creating the temp view to apply DQ rules
    source_file_df.createOrReplaceTempView(scr_id_dq['screen_name'])

    ## reading the filter/row rules from dq_rules based on screen_id
    row_rules_df = select_table(f"(select distinct * from dq_rules where screen_id={scr_id_dq['screen_id']} and rule_type='filter') dq_rules")
    print(row_rules_df)
    ##logger(LOGTYPE.INFO,'Row rules started',log_file)
    ## reading the profile/info rules from dq_rules based on screen_id
    info_rules_df = select_table(f"(select distinct * from dq_rules where screen_id={scr_id_dq['screen_id']} and rule_type='info') dq_rules")

    ## Temp Path to lo error records
    TEMPORARY_TARGET = f"{temp_folder_path}/{file[1]}".replace('.','_')

    if(row_rules_df.count()):
        
        ## Calling the row rule function to filter error records
        row_dq_count = apply_row_rules(source_file_df,row_rules_df,TEMPORARY_TARGET,scr_id_dq['screen_id'])
        convert_csv_from_part(TEMPORARY_TARGET,f"{error_folder_path}/{file[1]}")


    if(info_rules_df.count()):

        ## Calling the profile rule function to send alert error records
        profile_dq_count = apply_profile_rules(source_file_df,info_rules_df,TEMPORARY_TARGET,scr_id_dq['screen_id'])

    ## Temp path cleaning 
    deleteAllTheFIles(temp_folder_path)

    if(row_dq_count):
        ## call function to fiter errors from source file
        fiterErrorRecords(source_file_df,file)

    return source_file_df
    

# COMMAND ----------

def fiterErrorRecords(scrDF,file):

    ## Reading all error records from temp paht
    error_file_df = spark.read.option('header','true') \
        .option('inferschema',True).csv(f"{error_folder_path}/{file[1]}")
    
    filtered_df = scrDF.subtract(error_file_df)
    display(filtered_df)
    ## Temp Path to lo error records
    TEMPORARY_TARGET = f"{temp_folder_path}/{file[1]}/filtered".replace('.','_')

    ## Creating error file in temp path
    filtered_df.repartition(1).write.mode("overwrite").option("header", "true").option("delimiter", ",").csv(TEMPORARY_TARGET)

    convert_csv_from_part(TEMPORARY_TARGET,f"{processed_folder_path}/{file[1]}")

    os.remove(f"/{raw_folder_path}/{file[1]}".replace(':',''))



# COMMAND ----------

def validate_files():
    for i in files:
        for row in scr_df.rdd.collect():
            ## Checking DQ Screen for input file
            if(re.search(row['filename'], i[1])):
                scr_id_dq = scr_df.filter(col('filename')==row['filename']).rdd.collect()[0]
                if(scr_id_dq is not None):
                    source_file_df = apply_dq_rules(scr_id_dq,i)
                else:
                   print(f'No Rules for this file {i[1]}')


# COMMAND ----------

validate_files()