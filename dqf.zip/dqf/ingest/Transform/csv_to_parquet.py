# Databricks notebook source
# MAGIC %run "../../dq-rules-setup/configuration"

# COMMAND ----------

# MAGIC %run "./0.functions"

# COMMAND ----------

## reading all the files from path
files = readAllFIles(processed_folder_path)

# COMMAND ----------

def csvToParquet():

    for i in files:

        ## reading source file
        src_df = spark.read \
            .option('header',True) \
            .option('inferschema','true') \
            .csv(i[0])
        
        ## Converting Parquet
        src_df.write.mode("overwrite").parquet(f"{presentation_folder_path}/{i[1]}")
        display(src_df.count())
        ## Deleting source file
        dbutils.fs.cp(i[0], f'{archive_folder_path}/{i[1]}')
        os.remove('/'+i[0].replace(':',""))


# COMMAND ----------

csvToParquet()