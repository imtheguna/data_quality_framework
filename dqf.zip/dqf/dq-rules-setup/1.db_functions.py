# Databricks notebook source
# MAGIC %md
# MAGIC ## Creating AWS RDS Connection

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %run "./0.read_connection_details"

# COMMAND ----------

print(JDBC_Url)

# COMMAND ----------

def select_table(query):
    df = spark.read.jdbc(url=JDBC_Url ,table=query,properties=connProperties)
    return df

# COMMAND ----------

def insert_by_df(table,df):
    df.write.mode('append').jdbc(url=JDBC_Url,table=table,properties=connProperties)

# COMMAND ----------

def execute_query(query):
    con.prepareCall(query).execute()

# COMMAND ----------

def add_ingestion_date(input_df,column_name):
  output_df = input_df.withColumn(column_name, current_timestamp())
  return output_df

# COMMAND ----------

def add_column(input_df,column_name,value):
  output_df = input_df.withColumn(column_name, lit(value))
  return output_df