# Databricks notebook source
# MAGIC %run "./configuration"

# COMMAND ----------

df = spark.read.option('header',True).option('inferschema','true').csv(f'{setup_folder_path}/user.csv')
username = df.select('username').take(1)[0]['username']
database = df.select('database').take(1)[0]['database']
password = df.select('pass').take(1)[0]['pass']
host = df.select('host').take(1)[0]['host']
port = df.select('port').take(1)[0]['port']

# COMMAND ----------

JDBC_Url = "jdbc:postgresql://{}/{}".format(host,database)

# COMMAND ----------

connProperties = {
    'user':username,
    'password':password
}

# COMMAND ----------

# MAGIC %scala
# MAGIC Class.forName("org.postgresql.Driver")

# COMMAND ----------

df = spark.read.jdbc(url=JDBC_Url ,table='screen',praoperties=connProperties)

# COMMAND ----------

sql_driver_manager=spark._sc._gateway.jvm.java.sql.DriverManager
con = sql_driver_manager.getConnection(JDBC_Url+f'?user={username}&password={password}&autocommit=true')