# Databricks notebook source
import re
import os
import shutil
import time
from datetime import datetime

# COMMAND ----------

from enum import Enum
 
class LOGTYPE(Enum):
    INFO = 'INFO'
    ERROR = 'ERROR'

# COMMAND ----------

def mount_adls(storage_account_name, container_name):
    # Get secrets from Key Vault
    client_id = "7ed71d11-24c1-4d2c-9e36-0d27aff97f9f"
    tenant_id = "276bf9b8-b404-4825-969c-7ae22eeee0d4"
    client_secret = "NX48Q~UvlHLxgHE7md7CscUjFRnB5WI54SBesbJ~"
    
    # Set spark configurations
    configs = {"fs.azure.account.auth.type": "OAuth",
              "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
              "fs.azure.account.oauth2.client.id": client_id,
              "fs.azure.account.oauth2.client.secret": client_secret,
              "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}
    
    # Unmount the mount point if it already exists
    if any(mount.mountPoint == f"/mnt/{storage_account_name}/{container_name}" for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(f"/mnt/{storage_account_name}/{container_name}")
    
    # Mount the storage account container
    dbutils.fs.mount(
      source = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/",
      mount_point = f"/mnt/{storage_account_name}/{container_name}",
      extra_configs = configs)
    
    #display(dbutils.fs.mounts())

# COMMAND ----------

mount_adls('formula1dlg','dqf')

# COMMAND ----------

raw_folder_path = "dbfs:/mnt/formula1dlg/dqf/raw"
setup_folder_path = "dbfs:/mnt/formula1dlg/dqf/setup-file"
error_folder_path = "dbfs:/mnt/formula1dlg/dqf/error"
temp_folder_path = "dbfs:/mnt/formula1dlg/dqf/temp"
rules_folder_path = "dbfs:/mnt/formula1dlg/dqf/rules"
processed_folder_path = "dbfs:/mnt/formula1dlg/dqf/processed"
log_folder_path = "dbfs:/mnt/formula1dlg/dqf/log"
presentation_folder_path = "dbfs:/mnt/formula1dlg/dqf/presentation"
archive_folder_path = "dbfs:/mnt/formula1dlg/dqf/archive"